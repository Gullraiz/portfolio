import React, { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code, Palette, Zap, Users } from 'lucide-react';

const CyberpunkAbout: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  const stats = [
    { number: '5+', label: 'Years Experience' },
    { number: '100+', label: 'Projects Completed' },
    { number: '50+', label: 'Happy Clients' },
    { number: '24/7', label: 'Support Available' }
  ];

  const features = [
    {
      icon: <Code size={24} />,
      title: 'Clean Code',
      description: 'Writing maintainable, scalable code that stands the test of time'
    },
    {
      icon: <Palette size={24} />,
      title: 'Creative Design',
      description: 'Pushing boundaries with innovative design solutions'
    },
    {
      icon: <Zap size={24} />,
      title: 'Fast Performance',
      description: 'Optimized for speed and seamless user experiences'
    },
    {
      icon: <Users size={24} />,
      title: 'Team Player',
      description: 'Collaborative approach to achieve exceptional results'
    }
  ];

  useGSAP(() => {
    // Animate text reveal
    if (textRef.current) {
      gsap.fromTo(textRef.current.children,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.2,
          ease: "power2.out",
          scrollTrigger: {
            trigger: textRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }

    // Animate stats
    if (statsRef.current) {
      const statItems = statsRef.current.querySelectorAll('.stat-item');
      
      gsap.fromTo(statItems,
        { opacity: 0, scale: 0.8, y: 50 },
        {
          opacity: 1,
          scale: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: statsRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Counter animation
      statItems.forEach((item) => {
        const numberElement = item.querySelector('.stat-number');
        if (numberElement) {
          const finalNumber = numberElement.textContent;
          const numericValue = parseInt(finalNumber?.replace(/\D/g, '') || '0');
          
          ScrollTrigger.create({
            trigger: item,
            start: "top 80%",
            onEnter: () => {
              gsap.fromTo(numberElement, 
                { textContent: 0 },
                {
                  textContent: numericValue,
                  duration: 2,
                  ease: "power2.out",
                  snap: { textContent: 1 },
                  onUpdate: function() {
                    const current = Math.round(this.targets()[0].textContent);
                    numberElement.textContent = finalNumber?.includes('+') ? `${current}+` : 
                                               finalNumber?.includes('/') ? `${current}/7` : 
                                               current.toString();
                  }
                }
              );
            }
          });
        }
      });
    }

    // Animate feature cards
    if (cardsRef.current) {
      const cards = cardsRef.current.querySelectorAll('.feature-card');
      
      gsap.fromTo(cards,
        { opacity: 0, y: 100, rotateX: -90 },
        {
          opacity: 1,
          y: 0,
          rotateX: 0,
          duration: 0.8,
          stagger: 0.2,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: cardsRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }

  }, { scope: containerRef });

  return (
    <section id="about" ref={containerRef} className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-0 w-96 h-96 bg-cyber-blue/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-cyber-pink/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Text Content */}
          <div ref={textRef} className="space-y-8">
            <div>
              <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyber-blue to-cyber-pink bg-clip-text text-transparent">
                About Me
              </h2>
              <p className="text-lg text-gray-300 leading-relaxed mb-6">
                I'm a passionate cyberpunk-inspired designer and developer with over 5 years 
                of experience creating cutting-edge digital experiences. My work exists at the 
                intersection of technology and art, where neon meets functionality.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                Specializing in futuristic UI/UX design, I bring visions of tomorrow to life 
                through code, creating immersive digital environments that push the boundaries 
                of what's possible on the web.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              {['React', 'TypeScript', 'GSAP', 'Three.js', 'Figma', 'Blender'].map((tech) => (
                <span 
                  key={tech}
                  className="px-4 py-2 bg-cyber-black/50 border border-cyber-blue/30 rounded-lg text-sm font-medium hover:border-cyber-blue hover:shadow-cyber-glow-blue transition-all duration-300"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div ref={statsRef} className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <div 
                key={index}
                className="stat-item bg-cyber-black/30 border border-cyber-blue/20 rounded-xl p-6 text-center hover:border-cyber-blue/50 hover:shadow-cyber-glow-blue transition-all duration-300"
              >
                <div className="stat-number text-3xl font-black text-cyber-blue mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-400 text-sm font-mono">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Feature Cards */}
        <div ref={cardsRef} className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="feature-card bg-cyber-black/30 border border-cyber-blue/20 rounded-xl p-6 hover:border-cyber-blue/50 hover:shadow-cyber-glow-blue transition-all duration-300 group"
              style={{ transformStyle: 'preserve-3d' }}
              data-cursor-hover
            >
              <div className="text-cyber-blue mb-4 group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">
                {feature.title}
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CyberpunkAbout;