import React, { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Monitor, Smartphone, Palette, Code, Zap, Globe } from 'lucide-react';

const CyberpunkServices: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLDivElement>(null);

  const services = [
    {
      icon: <Monitor size={32} />,
      title: 'Web Development',
      description: 'Custom websites built with cutting-edge technologies and cyberpunk aesthetics',
      features: ['React/Next.js', 'TypeScript', 'GSAP Animations', 'Responsive Design']
    },
    {
      icon: <Smartphone size={32} />,
      title: 'Mobile Apps',
      description: 'Futuristic mobile applications that push the boundaries of user experience',
      features: ['React Native', 'Flutter', 'UI/UX Design', 'Performance Optimization']
    },
    {
      icon: <Palette size={32} />,
      title: 'UI/UX Design',
      description: 'Cyberpunk-inspired interfaces that blend form and function seamlessly',
      features: ['Figma Design', 'Prototyping', 'User Research', 'Design Systems']
    },
    {
      icon: <Code size={32} />,
      title: 'Frontend Development',
      description: 'Interactive frontends with smooth animations and modern frameworks',
      features: ['Vue.js', 'Angular', 'Three.js', 'WebGL Effects']
    },
    {
      icon: <Zap size={32} />,
      title: 'Performance Optimization',
      description: 'Lightning-fast websites optimized for the digital future',
      features: ['Core Web Vitals', 'Bundle Optimization', 'Caching Strategies', 'CDN Setup']
    },
    {
      icon: <Globe size={32} />,
      title: 'Digital Branding',
      description: 'Complete brand identity design for the cyberpunk era',
      features: ['Logo Design', 'Brand Guidelines', 'Digital Assets', 'Marketing Materials']
    }
  ];

  useGSAP(() => {
    // Animate title
    if (titleRef.current) {
      gsap.fromTo(titleRef.current.children,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.2,
          ease: "power2.out",
          scrollTrigger: {
            trigger: titleRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }

    // Animate service cards
    if (servicesRef.current) {
      const cards = servicesRef.current.querySelectorAll('.service-card');
      
      gsap.fromTo(cards,
        { opacity: 0, y: 100, rotateY: -90 },
        {
          opacity: 1,
          y: 0,
          rotateY: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: servicesRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Hover animations
      cards.forEach((card) => {
        const cardElement = card as HTMLElement;
        
        cardElement.addEventListener('mouseenter', () => {
          gsap.to(cardElement, {
            y: -10,
            scale: 1.02,
            duration: 0.3,
            ease: "power2.out"
          });
        });

        cardElement.addEventListener('mouseleave', () => {
          gsap.to(cardElement, {
            y: 0,
            scale: 1,
            duration: 0.3,
            ease: "power2.out"
          });
        });
      });
    }

  }, { scope: containerRef });

  return (
    <section id="services" ref={containerRef} className="py-20 relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-5">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 255, 255, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 255, 255, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '100px 100px'
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div ref={titleRef} className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow bg-clip-text text-transparent">
            Services
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Cutting-edge digital solutions for the cyberpunk era. From concept to deployment, 
            I craft experiences that define the future.
          </p>
        </div>

        <div ref={servicesRef} className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="service-card bg-cyber-black/30 border border-cyber-blue/20 rounded-xl p-8 hover:border-cyber-blue/50 hover:shadow-cyber-glow-blue transition-all duration-300 group"
              style={{ transformStyle: 'preserve-3d' }}
              data-cursor-hover
            >
              <div className="text-cyber-blue mb-6 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              
              <h3 className="text-2xl font-bold mb-4 text-white">
                {service.title}
              </h3>
              
              <p className="text-gray-400 mb-6 leading-relaxed">
                {service.description}
              </p>

              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li 
                    key={featureIndex}
                    className="text-sm text-gray-500 flex items-center"
                  >
                    <span className="w-1 h-1 bg-cyber-blue rounded-full mr-3" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button className="mt-6 w-full py-3 border border-cyber-blue/30 rounded-lg text-cyber-blue hover:bg-cyber-blue/10 hover:border-cyber-blue transition-all duration-300 font-medium">
                Learn More
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CyberpunkServices;