import React, { useRef, useState } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, Github } from 'lucide-react';

const CyberpunkPortfolio: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [activeFilter, setActiveFilter] = useState('all');

  const projects = [
    {
      id: 1,
      title: 'Neural Network Dashboard',
      category: 'web',
      image: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'AI-powered analytics dashboard with real-time data visualization',
      tech: ['React', 'D3.js', 'WebGL'],
      year: '2024'
    },
    {
      id: 2,
      title: 'Cyberpunk Mobile App',
      category: 'mobile',
      image: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'Futuristic mobile interface with neon aesthetics',
      tech: ['React Native', 'Expo', 'Lottie'],
      year: '2024'
    },
    {
      id: 3,
      title: 'Digital Art Gallery',
      category: 'design',
      image: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'Immersive 3D gallery experience for digital artists',
      tech: ['Three.js', 'WebXR', 'GSAP'],
      year: '2023'
    },
    {
      id: 4,
      title: 'Blockchain Explorer',
      category: 'web',
      image: 'https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'Real-time blockchain transaction explorer',
      tech: ['Vue.js', 'Web3.js', 'Chart.js'],
      year: '2023'
    },
    {
      id: 5,
      title: 'AR Shopping Experience',
      category: 'mobile',
      image: 'https://images.pexels.com/photos/1181316/pexels-photo-1181316.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'Augmented reality shopping application',
      tech: ['Unity', 'ARCore', 'C#'],
      year: '2023'
    },
    {
      id: 6,
      title: 'Neon Brand Identity',
      category: 'design',
      image: 'https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'Complete cyberpunk brand identity system',
      tech: ['Figma', 'After Effects', 'Illustrator'],
      year: '2024'
    }
  ];

  const filters = [
    { id: 'all', label: 'All Projects' },
    { id: 'web', label: 'Web Apps' },
    { id: 'mobile', label: 'Mobile' },
    { id: 'design', label: 'Design' }
  ];

  const filteredProjects = activeFilter === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  useGSAP(() => {
    if (gridRef.current) {
      const cards = gridRef.current.querySelectorAll('.project-card');
      
      gsap.fromTo(cards,
        { opacity: 0, y: 100, scale: 0.8 },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: gridRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Magnetic hover effect
      cards.forEach((card) => {
        const cardElement = card as HTMLElement;
        
        cardElement.addEventListener('mouseenter', () => {
          gsap.to(cardElement, {
            scale: 1.05,
            duration: 0.3,
            ease: "power2.out"
          });
        });

        cardElement.addEventListener('mouseleave', () => {
          gsap.to(cardElement, {
            scale: 1,
            x: 0,
            y: 0,
            duration: 0.3,
            ease: "power2.out"
          });
        });

        cardElement.addEventListener('mousemove', (e) => {
          const rect = cardElement.getBoundingClientRect();
          const x = e.clientX - rect.left - rect.width / 2;
          const y = e.clientY - rect.top - rect.height / 2;
          
          gsap.to(cardElement, {
            x: x * 0.1,
            y: y * 0.1,
            duration: 0.3,
            ease: "power2.out"
          });
        });
      });
    }
  }, { scope: containerRef, dependencies: [filteredProjects] });

  const handleFilterChange = (filterId: string) => {
    setActiveFilter(filterId);
    
    if (gridRef.current) {
      const cards = gridRef.current.querySelectorAll('.project-card');
      
      gsap.to(cards, {
        opacity: 0,
        y: 50,
        duration: 0.3,
        stagger: 0.05,
        ease: "power2.inOut",
        onComplete: () => {
          gsap.fromTo(cards,
            { opacity: 0, y: 50 },
            {
              opacity: 1,
              y: 0,
              duration: 0.5,
              stagger: 0.05,
              ease: "power2.out"
            }
          );
        }
      });
    }
  };

  return (
    <section id="portfolio" ref={containerRef} className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyber-pink/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyber-yellow/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow bg-clip-text text-transparent">
            Portfolio
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            A showcase of cutting-edge projects that push the boundaries of digital design and development
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => handleFilterChange(filter.id)}
              className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                activeFilter === filter.id
                  ? 'bg-gradient-to-r from-cyber-blue to-cyber-pink text-white shadow-cyber-glow-blue'
                  : 'bg-cyber-black/30 border border-cyber-blue/30 text-gray-300 hover:border-cyber-blue hover:text-cyber-blue'
              }`}
              data-cursor-hover
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Project Grid */}
        <div ref={gridRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="project-card bg-cyber-black/30 border border-cyber-blue/20 rounded-xl overflow-hidden hover:border-cyber-blue/50 hover:shadow-cyber-glow-blue transition-all duration-300 group"
              data-cursor-hover
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cyber-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="flex gap-2">
                    <button className="p-2 bg-cyber-blue/20 backdrop-blur-sm rounded-lg text-cyber-blue hover:bg-cyber-blue/30 transition-colors">
                      <ExternalLink size={16} />
                    </button>
                    <button className="p-2 bg-cyber-pink/20 backdrop-blur-sm rounded-lg text-cyber-pink hover:bg-cyber-pink/30 transition-colors">
                      <Github size={16} />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-white">{project.title}</h3>
                  <span className="text-xs text-cyber-blue font-mono">{project.year}</span>
                </div>
                
                <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map((tech, index) => (
                    <span 
                      key={index}
                      className="px-2 py-1 bg-cyber-blue/10 border border-cyber-blue/30 rounded text-xs text-cyber-blue font-mono"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <button className="w-full py-2 border border-cyber-blue/30 rounded-lg text-cyber-blue hover:bg-cyber-blue/10 hover:border-cyber-blue transition-all duration-300 text-sm font-medium">
                  View Project
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CyberpunkPortfolio;