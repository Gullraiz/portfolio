import React, { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Zap, Star, Crown } from 'lucide-react';

const CyberpunkPricing: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  const plans = [
    {
      name: 'Neural Basic',
      price: '$999',
      period: 'per project',
      icon: <Zap size={32} />,
      color: 'cyber-blue',
      features: [
        'Responsive Web Design',
        'Basic Animations',
        '3 Revisions',
        'Mobile Optimization',
        'SEO Optimization',
        '30 Days Support'
      ],
      popular: false
    },
    {
      name: 'Cyber Pro',
      price: '$2,499',
      period: 'per project',
      icon: <Star size={32} />,
      color: 'cyber-pink',
      features: [
        'Advanced Web Application',
        'GSAP Animations',
        'Three.js Integration',
        'Unlimited Revisions',
        'Performance Optimization',
        'API Integration',
        '90 Days Support',
        'Source Code Included'
      ],
      popular: true
    },
    {
      name: 'Matrix Elite',
      price: '$4,999',
      period: 'per project',
      icon: <Crown size={32} />,
      color: 'cyber-yellow',
      features: [
        'Full-Stack Development',
        'Custom 3D Experiences',
        'WebGL Shaders',
        'Real-time Features',
        'Database Design',
        'DevOps Setup',
        'Unlimited Revisions',
        '6 Months Support',
        'Training Included'
      ],
      popular: false
    }
  ];

  useGSAP(() => {
    if (cardsRef.current) {
      const cards = cardsRef.current.querySelectorAll('.pricing-card');
      
      gsap.fromTo(cards,
        { opacity: 0, y: 100, scale: 0.8 },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.8,
          stagger: 0.2,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: cardsRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Hover animations
      cards.forEach((card) => {
        const cardElement = card as HTMLElement;
        
        cardElement.addEventListener('mouseenter', () => {
          gsap.to(cardElement, {
            y: -20,
            scale: 1.05,
            duration: 0.3,
            ease: "power2.out"
          });
        });

        cardElement.addEventListener('mouseleave', () => {
          gsap.to(cardElement, {
            y: 0,
            scale: 1,
            duration: 0.3,
            ease: "power2.out"
          });
        });
      });
    }
  }, { scope: containerRef });

  return (
    <section ref={containerRef} className="py-20 relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-5">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255, 221, 0, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255, 221, 0, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px'
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow bg-clip-text text-transparent">
            Pricing
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Choose your path to the digital future. All plans include cyberpunk aesthetics and cutting-edge technology.
          </p>
        </div>

        <div ref={cardsRef} className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`pricing-card relative bg-cyber-black/30 border rounded-xl p-8 transition-all duration-300 group ${
                plan.popular 
                  ? 'border-cyber-pink shadow-cyber-glow-pink scale-105' 
                  : 'border-cyber-blue/20 hover:border-cyber-blue/50 hover:shadow-cyber-glow-blue'
              }`}
              data-cursor-hover
            >
              {/* Popular badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-cyber-pink to-purple-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                </div>
              )}

              {/* Icon */}
              <div className={`text-${plan.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                {plan.icon}
              </div>

              {/* Plan name */}
              <h3 className="text-2xl font-bold text-white mb-2">
                {plan.name}
              </h3>

              {/* Price */}
              <div className="mb-6">
                <span className={`text-4xl font-black text-${plan.color}`}>
                  {plan.price}
                </span>
                <span className="text-gray-400 text-sm ml-2">
                  {plan.period}
                </span>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-gray-300">
                    <Check size={16} className={`text-${plan.color} mr-3 flex-shrink-0`} />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <button 
                className={`w-full py-4 rounded-lg font-medium transition-all duration-300 ${
                  plan.popular
                    ? 'bg-gradient-to-r from-cyber-pink to-purple-600 text-white hover:shadow-cyber-glow-pink'
                    : `border border-${plan.color}/30 text-${plan.color} hover:bg-${plan.color}/10 hover:border-${plan.color}`
                }`}
              >
                Get Started
              </button>

              {/* Glowing effect */}
              <div className={`absolute inset-0 rounded-xl bg-${plan.color}/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10`} />
            </div>
          ))}
        </div>

        {/* Additional info */}
        <div className="text-center mt-12">
          <p className="text-gray-400 mb-4">
            Need a custom solution? Let's discuss your cyberpunk vision.
          </p>
          <button className="px-8 py-3 border border-cyber-blue/30 rounded-lg text-cyber-blue hover:bg-cyber-blue/10 hover:border-cyber-blue transition-all duration-300 font-medium">
            Contact for Custom Quote
          </button>
        </div>
      </div>
    </section>
  );
};

export default CyberpunkPricing;