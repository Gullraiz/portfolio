import React, { useRef, useState } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Phone, MapPin, Send, MessageCircle, Calendar } from 'lucide-react';

const CyberpunkContact: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    project: '',
    budget: '',
    message: ''
  });

  const contactInfo = [
    {
      icon: <Mail size={24} />,
      title: 'Neural Link',
      content: 'cyber@designer.dev',
      action: 'mailto:cyber@designer.dev',
      color: 'cyber-blue'
    },
    {
      icon: <Phone size={24} />,
      title: 'Direct Line',
      content: '+1 (555) CYBER-01',
      action: 'tel:+15552923701',
      color: 'cyber-pink'
    },
    {
      icon: <MapPin size={24} />,
      title: 'Location',
      content: 'Neo Tokyo, Sector 7',
      action: '#',
      color: 'cyber-yellow'
    },
    {
      icon: <MessageCircle size={24} />,
      title: 'Discord',
      content: 'CyberDev#2077',
      action: '#',
      color: 'cyber-blue'
    },
    {
      icon: <Calendar size={24} />,
      title: 'Schedule Call',
      content: 'Book a meeting',
      action: '#',
      color: 'cyber-pink'
    }
  ];

  useGSAP(() => {
    // Animate form elements
    if (formRef.current) {
      const formElements = formRef.current.querySelectorAll('.form-element');
      
      gsap.fromTo(formElements,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: formRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }

    // Animate contact cards
    if (cardsRef.current) {
      const cards = cardsRef.current.querySelectorAll('.contact-card');
      
      gsap.fromTo(cards,
        { opacity: 0, y: 100, rotateY: -90 },
        {
          opacity: 1,
          y: 0,
          rotateY: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: cardsRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Floating animation for cards
      cards.forEach((card, index) => {
        gsap.to(card, {
          y: -10,
          duration: 2 + index * 0.3,
          ease: "power2.inOut",
          yoyo: true,
          repeat: -1,
          delay: index * 0.2
        });
      });
    }
  }, { scope: containerRef });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <section id="contact" ref={containerRef} className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-cyber-blue/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyber-pink/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-cyber-yellow/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '4s' }} />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow bg-clip-text text-transparent">
            Contact
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Ready to jack into the cyberpunk future? Let's create something that will redefine digital reality.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <div>
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
              <div className="form-element">
                <label htmlFor="name" className="block text-sm font-medium mb-2 text-cyber-blue">
                  Neural ID
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-cyber-black/50 border border-cyber-blue/30 rounded-lg focus:ring-2 focus:ring-cyber-blue focus:border-transparent transition-all duration-300 text-white placeholder-gray-500"
                  placeholder="Your designation"
                  required
                />
              </div>

              <div className="form-element">
                <label htmlFor="email" className="block text-sm font-medium mb-2 text-cyber-pink">
                  Data Stream
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-cyber-black/50 border border-cyber-pink/30 rounded-lg focus:ring-2 focus:ring-cyber-pink focus:border-transparent transition-all duration-300 text-white placeholder-gray-500"
                  placeholder="neural@link.dev"
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="form-element">
                  <label htmlFor="project" className="block text-sm font-medium mb-2 text-cyber-yellow">
                    Project Type
                  </label>
                  <select
                    id="project"
                    name="project"
                    value={formData.project}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-cyber-black/50 border border-cyber-yellow/30 rounded-lg focus:ring-2 focus:ring-cyber-yellow focus:border-transparent transition-all duration-300 text-white"
                    required
                  >
                    <option value="">Select project type</option>
                    <option value="web">Web Application</option>
                    <option value="mobile">Mobile App</option>
                    <option value="design">UI/UX Design</option>
                    <option value="branding">Digital Branding</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div className="form-element">
                  <label htmlFor="budget" className="block text-sm font-medium mb-2 text-cyber-blue">
                    Budget Range
                  </label>
                  <select
                    id="budget"
                    name="budget"
                    value={formData.budget}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-cyber-black/50 border border-cyber-blue/30 rounded-lg focus:ring-2 focus:ring-cyber-blue focus:border-transparent transition-all duration-300 text-white"
                    required
                  >
                    <option value="">Select budget</option>
                    <option value="1k-5k">$1K - $5K</option>
                    <option value="5k-10k">$5K - $10K</option>
                    <option value="10k-25k">$10K - $25K</option>
                    <option value="25k+">$25K+</option>
                  </select>
                </div>
              </div>

              <div className="form-element">
                <label htmlFor="message" className="block text-sm font-medium mb-2 text-cyber-pink">
                  Mission Brief
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={6}
                  className="w-full px-4 py-3 bg-cyber-black/50 border border-cyber-pink/30 rounded-lg focus:ring-2 focus:ring-cyber-pink focus:border-transparent transition-all duration-300 resize-none text-white placeholder-gray-500"
                  placeholder="Describe your vision for the digital future..."
                  required
                />
              </div>

              <button
                type="submit"
                className="form-element w-full bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow text-white font-medium py-4 px-6 rounded-lg transition-all duration-300 flex items-center justify-center gap-2 hover:shadow-cyber-glow-blue transform hover:scale-105"
                data-cursor-hover
              >
                <Send size={20} />
                Initialize Connection
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div ref={cardsRef} className="space-y-4">
            {contactInfo.map((info, index) => (
              <div
                key={index}
                className={`contact-card bg-cyber-black/30 border border-${info.color}/20 rounded-xl p-6 hover:border-${info.color}/50 hover:shadow-cyber-glow-${info.color.split('-')[1]} transition-all duration-300 cursor-pointer group`}
                data-cursor-hover
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div className="flex items-center gap-4">
                  <div className={`flex-shrink-0 w-12 h-12 bg-${info.color}/20 rounded-lg flex items-center justify-center text-${info.color} group-hover:scale-110 transition-transform duration-300`}>
                    {info.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1 text-white">{info.title}</h3>
                    <p className="text-gray-400 font-mono text-sm">{info.content}</p>
                  </div>
                </div>
              </div>
            ))}

            {/* Status indicator */}
            <div className="contact-card bg-green-900/20 border border-green-500/30 rounded-xl p-6">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                <span className="font-medium text-green-400">
                  Status: Online & Available
                </span>
              </div>
              <p className="text-sm text-green-300/70 mt-2 font-mono">
                Response time: &lt; 24 hours
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CyberpunkContact;