import React, { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const CyberpunkSkills: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);

  const skills = [
    { name: 'React/Next.js', level: 95, color: 'cyber-blue' },
    { name: 'TypeScript', level: 90, color: 'cyber-pink' },
    { name: 'GSAP Animation', level: 85, color: 'cyber-yellow' },
    { name: 'Three.js/WebGL', level: 80, color: 'cyber-blue' },
    { name: 'UI/UX Design', level: 88, color: 'cyber-pink' },
    { name: 'Node.js', level: 82, color: 'cyber-yellow' },
    { name: 'Python', level: 75, color: 'cyber-blue' },
    { name: 'Figma/Design', level: 92, color: 'cyber-pink' }
  ];

  useGSAP(() => {
    if (skillsRef.current) {
      const skillBars = skillsRef.current.querySelectorAll('.skill-item');
      const skillFills = skillsRef.current.querySelectorAll('.skill-fill');
      
      gsap.fromTo(skillBars,
        { opacity: 0, x: -100 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: skillsRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      skillFills.forEach((fill, index) => {
        gsap.fromTo(fill,
          { width: '0%' },
          {
            width: `${skills[index].level}%`,
            duration: 1.5,
            ease: "power2.out",
            scrollTrigger: {
              trigger: fill,
              start: "top 80%",
              end: "bottom 20%",
              toggleActions: "play none none reverse"
            }
          }
        );
      });
    }
  }, { scope: containerRef });

  return (
    <section id="skills" ref={containerRef} className="py-20 relative overflow-hidden">
      {/* Animated background grid */}
      <div className="absolute inset-0 opacity-5">
        <div 
          className="absolute inset-0 animate-pulse"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255, 16, 240, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255, 16, 240, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '80px 80px'
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow bg-clip-text text-transparent">
            Skills
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Mastering the technologies that power the digital future
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Skills List */}
          <div ref={skillsRef} className="space-y-8">
            {skills.map((skill, index) => (
              <div key={skill.name} className="skill-item">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-medium text-white text-lg">{skill.name}</span>
                  <span className="text-sm text-gray-400 font-mono">{skill.level}%</span>
                </div>
                <div className="relative">
                  <div className="w-full bg-cyber-black/50 border border-gray-700 rounded-full h-3 overflow-hidden">
                    <div 
                      className={`skill-fill h-full rounded-full relative ${
                        skill.color === 'cyber-blue' ? 'bg-gradient-to-r from-cyber-blue to-cyan-400' :
                        skill.color === 'cyber-pink' ? 'bg-gradient-to-r from-cyber-pink to-pink-400' :
                        'bg-gradient-to-r from-cyber-yellow to-yellow-400'
                      }`}
                      style={{ width: '0%' }}
                    >
                      <div className="absolute inset-0 bg-white/20 animate-pulse" />
                    </div>
                  </div>
                  {/* Glowing effect */}
                  <div 
                    className={`absolute top-0 left-0 h-full rounded-full blur-sm opacity-50 ${
                      skill.color === 'cyber-blue' ? 'bg-cyber-blue' :
                      skill.color === 'cyber-pink' ? 'bg-cyber-pink' :
                      'bg-cyber-yellow'
                    }`}
                    style={{ width: '0%' }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Visual Element */}
          <div className="relative">
            <div className="relative w-full h-96 bg-cyber-black/30 border border-cyber-blue/20 rounded-xl overflow-hidden">
              {/* Code-like visual */}
              <div className="absolute inset-0 p-6 font-mono text-sm">
                <div className="text-cyber-blue mb-2">{'// Cyberpunk Developer'}</div>
                <div className="text-gray-400 mb-4">{'const skills = {'}</div>
                <div className="ml-4 space-y-1">
                  <div className="text-cyber-pink">frontend: <span className="text-cyber-yellow">'React, TypeScript'</span>,</div>
                  <div className="text-cyber-pink">animation: <span className="text-cyber-yellow">'GSAP, Three.js'</span>,</div>
                  <div className="text-cyber-pink">design: <span className="text-cyber-yellow">'Figma, UI/UX'</span>,</div>
                  <div className="text-cyber-pink">backend: <span className="text-cyber-yellow">'Node.js, Python'</span></div>
                </div>
                <div className="text-gray-400 mt-4">{'};'}</div>
                
                <div className="mt-8 text-cyber-blue">{'// Always learning, always evolving'}</div>
                <div className="text-gray-400">{'console.log("Welcome to the future");'}</div>
              </div>

              {/* Animated cursor */}
              <div className="absolute bottom-6 right-6 w-2 h-4 bg-cyber-blue animate-pulse" />
            </div>

            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 w-8 h-8 bg-cyber-pink/20 rounded-full animate-pulse" />
            <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-cyber-yellow/20 rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
            <div className="absolute top-1/2 -left-8 w-4 h-4 bg-cyber-blue/20 rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default CyberpunkSkills;