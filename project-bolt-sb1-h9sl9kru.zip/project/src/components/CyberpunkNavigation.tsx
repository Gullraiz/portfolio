import React, { useRef, useState } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { Menu, X } from 'lucide-react';

const CyberpunkNavigation: React.FC = () => {
  const navRef = useRef<HTMLDivElement>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Portfolio', href: '#portfolio' },
    { label: 'Skills', href: '#skills' },
    { label: 'Contact', href: '#contact' }
  ];

  useGSAP(() => {
    if (navRef.current) {
      gsap.fromTo(navRef.current,
        { y: -100, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, delay: 0.5, ease: "power2.out" }
      );
    }
  }, { scope: navRef });

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav 
      ref={navRef}
      className="fixed top-0 left-0 right-0 z-40 p-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="bg-cyber-black/20 backdrop-blur-md border border-cyber-blue/20 rounded-2xl px-6 py-4">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <div className="text-2xl font-bold bg-gradient-to-r from-cyber-blue to-cyber-pink bg-clip-text text-transparent">
              CYBER.DEV
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <button
                  key={item.label}
                  onClick={() => scrollToSection(item.href)}
                  className="relative text-sm font-medium text-gray-300 hover:text-cyber-blue transition-colors duration-300 group"
                  data-cursor-hover
                >
                  {item.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-cyber-blue group-hover:w-full transition-all duration-300" />
                </button>
              ))}
              
              <button 
                className="px-6 py-2 bg-gradient-to-r from-cyber-blue to-cyber-pink rounded-lg text-sm font-medium hover:shadow-cyber-glow-blue transition-all duration-300"
                data-cursor-hover
              >
                Hire Me
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-cyber-blue"
              data-cursor-hover
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 pt-4 border-t border-cyber-blue/20">
              <div className="flex flex-col gap-4">
                {navItems.map((item) => (
                  <button
                    key={item.label}
                    onClick={() => scrollToSection(item.href)}
                    className="text-left text-gray-300 hover:text-cyber-blue transition-colors duration-300"
                    data-cursor-hover
                  >
                    {item.label}
                  </button>
                ))}
                <button 
                  className="mt-4 px-6 py-2 bg-gradient-to-r from-cyber-blue to-cyber-pink rounded-lg text-sm font-medium hover:shadow-cyber-glow-blue transition-all duration-300 self-start"
                  data-cursor-hover
                >
                  Hire Me
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default CyberpunkNavigation;