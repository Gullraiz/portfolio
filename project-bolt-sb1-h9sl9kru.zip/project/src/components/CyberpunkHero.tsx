import React, { useRef, useEffect } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { TextPlugin } from 'gsap/TextPlugin';
import { ChevronDown } from 'lucide-react';

const CyberpunkHero: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const glitchRef = useRef<HTMLDivElement>(null);
  const scrollIndicatorRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const nameRef = useRef<HTMLDivElement>(null);

  const scrollToPortfolio = () => {
    const portfolioSection = document.querySelector('#portfolio');
    if (portfolioSection) {
      portfolioSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useGSAP(() => {
    const tl = gsap.timeline({ delay: 1 });

    // Image reveal animation
    if (imageRef.current) {
      tl.fromTo(imageRef.current,
        { opacity: 0, scale: 0.8, y: 50 },
        { opacity: 1, scale: 1, y: 0, duration: 1.2, ease: "back.out(1.7)" }
      );
    }

    // Name reveal animation
    if (nameRef.current) {
      tl.fromTo(nameRef.current,
        { opacity: 0, x: -100 },
        { opacity: 1, x: 0, duration: 1, ease: "power2.out" },
        "-=0.8"
      );
    }

    // Glitch effect for title
    if (titleRef.current && glitchRef.current) {
      // Initial reveal
      tl.fromTo(titleRef.current,
        { opacity: 0, y: 100 },
        { opacity: 1, y: 0, duration: 1, ease: "power2.out" },
        "-=0.6"
      );

      // Glitch animation
      const glitchTl = gsap.timeline({ repeat: -1, repeatDelay: 4 });
      glitchTl
        .to(glitchRef.current, {
          opacity: 1,
          duration: 0.1,
          ease: "none"
        })
        .to(glitchRef.current, {
          x: -2,
          duration: 0.05,
          ease: "none"
        })
        .to(glitchRef.current, {
          x: 2,
          duration: 0.05,
          ease: "none"
        })
        .to(glitchRef.current, {
          x: 0,
          opacity: 0,
          duration: 0.1,
          ease: "none"
        });
    }

    // Typewriter effect for subtitle
    if (subtitleRef.current) {
      tl.fromTo(subtitleRef.current,
        { opacity: 0 },
        { 
          opacity: 1, 
          duration: 0.5,
          ease: "power2.out"
        },
        "-=0.5"
      )
      .to(subtitleRef.current, {
        text: "Crafting visual stories that captivate and inspire",
        duration: 2,
        ease: "none"
      });
    }

    // Scroll indicator
    if (scrollIndicatorRef.current) {
      tl.fromTo(scrollIndicatorRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1, ease: "power2.out" },
        "-=1"
      );

      // Floating animation
      gsap.to(scrollIndicatorRef.current, {
        y: 10,
        duration: 2,
        ease: "power2.inOut",
        yoyo: true,
        repeat: -1
      });
    }

    // Continuous floating animation for image
    if (imageRef.current) {
      gsap.to(imageRef.current, {
        y: -15,
        duration: 3,
        ease: "power2.inOut",
        yoyo: true,
        repeat: -1,
        delay: 2
      });
    }

  }, { scope: containerRef });

  return (
    <section 
      id="home"
      ref={containerRef}
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
    >
      {/* Animated grid background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyber-blue/20 to-transparent animate-pulse" />
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-cyber-blue rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      <div className="relative z-10 px-6 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left side - Text content */}
          <div className="text-left">
            {/* Name */}
            <div ref={nameRef} className="mb-6">
              <span className="text-cyber-blue font-mono text-lg mb-2 block">Hello, I'm</span>
              <h1 className="text-4xl md:text-5xl font-black text-white mb-2">
                Gullraiz K.
              </h1>
            </div>

            {/* Title with glitch effect */}
            <div className="relative mb-8">
              <h2 
                ref={titleRef}
                className="text-5xl md:text-7xl lg:text-8xl font-black leading-none bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow bg-clip-text text-transparent"
              >
                GRAPHIC
                <br />
                DESIGNER
              </h2>
              
              {/* Glitch overlay */}
              <div 
                ref={glitchRef}
                className="absolute inset-0 text-5xl md:text-7xl lg:text-8xl font-black leading-none text-cyber-pink opacity-0 mix-blend-multiply"
              >
                GRAPHIC
                <br />
                DESIGNER
              </div>
            </div>
            
            <p 
              ref={subtitleRef}
              className="text-xl md:text-2xl text-gray-300 mb-12 max-w-xl font-mono"
            >
              {/* Text will be animated via GSAP */}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-16">
              <button 
                onClick={scrollToPortfolio}
                className="px-8 py-4 bg-gradient-to-r from-cyber-blue to-cyber-pink rounded-lg font-medium hover:shadow-cyber-glow-blue transition-all duration-300 transform hover:scale-105"
                data-cursor-hover
              >
                View My Work
              </button>
              <button 
                className="px-8 py-4 border border-cyber-blue rounded-lg font-medium hover:bg-cyber-blue/10 hover:shadow-cyber-glow-blue transition-all duration-300"
                data-cursor-hover
              >
                Download CV
              </button>
            </div>
          </div>

          {/* Right side - Image */}
          <div className="relative flex justify-center lg:justify-end">
            <div ref={imageRef} className="relative">
              {/* Main image container with cyberpunk effects */}
              <div className="relative">
                {/* Glowing border effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow rounded-2xl blur-lg opacity-30 animate-pulse" />
                
                {/* Image container */}
                <div className="relative bg-cyber-black/20 backdrop-blur-sm border border-cyber-blue/30 rounded-2xl p-4 hover:border-cyber-blue/50 transition-all duration-300">
                  <img
                    src="/freepik__background__39341.png"
                    alt="Gullraiz K. - Graphic Designer"
                    className="w-80 h-96 object-cover rounded-xl"
                  />
                  
                  {/* Overlay effects */}
                  <div className="absolute inset-4 rounded-xl bg-gradient-to-t from-cyber-black/60 via-transparent to-transparent pointer-events-none" />
                  
                  {/* Scan line effect */}
                  <div className="absolute inset-4 rounded-xl overflow-hidden pointer-events-none">
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-cyber-blue animate-pulse opacity-60" 
                         style={{ 
                           animation: 'scan 3s linear infinite',
                           background: 'linear-gradient(90deg, transparent, #00FFFF, transparent)'
                         }} />
                  </div>
                </div>

                {/* Floating UI elements around image */}
                <div className="absolute -top-4 -right-4 bg-cyber-black/80 backdrop-blur-sm border border-cyber-pink/30 rounded-lg px-3 py-2">
                  <span className="text-cyber-pink text-sm font-mono">ONLINE</span>
                </div>

                <div className="absolute -bottom-4 -left-4 bg-cyber-black/80 backdrop-blur-sm border border-cyber-yellow/30 rounded-lg px-3 py-2">
                  <span className="text-cyber-yellow text-sm font-mono">CREATIVE_MODE</span>
                </div>

                <div className="absolute top-1/2 -left-8 bg-cyber-black/80 backdrop-blur-sm border border-cyber-blue/30 rounded-lg px-2 py-1">
                  <span className="text-cyber-blue text-xs font-mono">5+ YRS</span>
                </div>

                {/* Geometric shapes */}
                <div className="absolute -top-8 left-1/4 w-4 h-4 border-2 border-cyber-blue/50 rotate-45 animate-pulse" />
                <div className="absolute -bottom-8 right-1/4 w-6 h-6 border-2 border-cyber-pink/50 rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
                <div className="absolute top-1/4 -right-8 w-3 h-8 bg-cyber-yellow/30 animate-pulse" style={{ animationDelay: '2s' }} />
              </div>
            </div>
          </div>
        </div>

        <div 
          ref={scrollIndicatorRef}
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 cursor-pointer"
          data-cursor-hover
          onClick={scrollToPortfolio}
        >
          <div className="flex flex-col items-center">
            <span className="text-sm mb-2 text-gray-400 font-mono">SCROLL_TO_EXPLORE</span>
            <ChevronDown size={24} className="text-cyber-blue" />
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes scan {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(400px); }
        }
      `}</style>
    </section>
  );
};

export default CyberpunkHero;