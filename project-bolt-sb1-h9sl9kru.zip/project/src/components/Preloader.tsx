import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const Preloader: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline();

    // Animate progress bar
    tl.to(progressRef.current, {
      width: '100%',
      duration: 2,
      ease: "power2.out"
    });

    // Animate text
    tl.fromTo(textRef.current,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.5 },
      0.5
    );

    // Fade out preloader
    tl.to(containerRef.current, {
      opacity: 0,
      duration: 0.5,
      delay: 0.5
    });

  }, []);

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 bg-white dark:bg-gray-900 flex items-center justify-center z-50"
    >
      <div className="text-center">
        <div ref={textRef} className="mb-8">
          <h1 className="text-4xl font-black text-gray-900 dark:text-white mb-4">
            Loading Portfolio
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Preparing something amazing...
          </p>
        </div>
        
        <div className="w-64 h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div 
            ref={progressRef}
            className="h-full bg-gradient-to-r from-blue-500 to-purple-600 w-0 rounded-full"
          />
        </div>
      </div>
    </div>
  );
};

export default Preloader;