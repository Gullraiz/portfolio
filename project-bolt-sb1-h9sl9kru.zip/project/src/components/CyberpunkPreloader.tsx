import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const CyberpunkPreloader: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const glitchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline();

    // Glitch effect
    const glitchTl = gsap.timeline({ repeat: -1, repeatDelay: 1 });
    glitchTl
      .to(glitchRef.current, {
        opacity: 1,
        duration: 0.1,
        ease: "none"
      })
      .to(glitchRef.current, {
        x: -3,
        duration: 0.05,
        ease: "none"
      })
      .to(glitchRef.current, {
        x: 3,
        duration: 0.05,
        ease: "none"
      })
      .to(glitchRef.current, {
        x: 0,
        opacity: 0,
        duration: 0.1,
        ease: "none"
      });

    // Progress bar animation
    tl.to(progressRef.current, {
      width: '100%',
      duration: 2.5,
      ease: "power2.out"
    });

    // Text animation
    tl.fromTo(textRef.current,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.5 },
      0.5
    );

    // Fade out preloader
    tl.to(containerRef.current, {
      opacity: 0,
      duration: 0.5,
      delay: 0.3
    });

  }, []);

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 bg-cyber-black flex items-center justify-center z-50"
    >
      {/* Background grid */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 255, 255, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 255, 255, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      <div className="text-center relative z-10">
        <div ref={textRef} className="mb-8">
          <div className="relative">
            <h1 className="text-4xl font-black text-white mb-4 font-mono">
              INITIALIZING NEURAL LINK
            </h1>
            
            {/* Glitch overlay */}
            <div 
              ref={glitchRef}
              className="absolute inset-0 text-4xl font-black text-cyber-pink opacity-0 mix-blend-multiply font-mono"
            >
              INITIALIZING NEURAL LINK
            </div>
          </div>
          
          <p className="text-gray-400 font-mono text-sm">
            Connecting to the cyberpunk matrix...
          </p>
        </div>
        
        <div className="w-80 h-1 bg-cyber-black border border-cyber-blue/30 rounded-full overflow-hidden">
          <div 
            ref={progressRef}
            className="h-full bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow w-0 rounded-full relative"
          >
            <div className="absolute inset-0 bg-white/20 animate-pulse" />
          </div>
        </div>

        {/* Loading dots */}
        <div className="flex justify-center gap-2 mt-6">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="w-2 h-2 bg-cyber-blue rounded-full animate-pulse"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default CyberpunkPreloader;