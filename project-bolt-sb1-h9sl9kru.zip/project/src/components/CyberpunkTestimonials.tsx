import React, { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Star, Quote } from 'lucide-react';

const CyberpunkTestimonials: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  const testimonials = [
    {
      name: 'Alex Chen',
      role: 'CEO, NeoTech Corp',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'Absolutely mind-blowing work! The cyberpunk aesthetic combined with flawless functionality exceeded all our expectations. This is the future of web design.',
      rating: 5,
      company: 'NeoTech'
    },
    {
      name: 'Sarah Matrix',
      role: 'Creative Director, Digital Nexus',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'Working with this developer was like stepping into the future. The attention to detail and innovative approach to design is unmatched in the industry.',
      rating: 5,
      company: 'Digital Nexus'
    },
    {
      name: 'Marcus Blade',
      role: 'Founder, CyberStart',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'The perfect blend of cutting-edge technology and stunning visual design. Our users are completely mesmerized by the experience.',
      rating: 5,
      company: 'CyberStart'
    }
  ];

  useGSAP(() => {
    if (cardsRef.current) {
      const cards = cardsRef.current.querySelectorAll('.testimonial-card');
      
      gsap.fromTo(cards,
        { opacity: 0, y: 100, rotateX: -90 },
        {
          opacity: 1,
          y: 0,
          rotateX: 0,
          duration: 0.8,
          stagger: 0.2,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: cardsRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Floating animation
      cards.forEach((card, index) => {
        gsap.to(card, {
          y: -10,
          duration: 3 + index * 0.5,
          ease: "power2.inOut",
          yoyo: true,
          repeat: -1,
          delay: index * 0.5
        });
      });
    }
  }, { scope: containerRef });

  return (
    <section ref={containerRef} className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/3 left-0 w-96 h-96 bg-cyber-blue/5 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/3 right-0 w-96 h-96 bg-cyber-pink/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black mb-6 bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow bg-clip-text text-transparent">
            Testimonials
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            What clients say about working in the cyberpunk digital realm
          </p>
        </div>

        <div ref={cardsRef} className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="testimonial-card bg-cyber-black/30 border border-cyber-blue/20 rounded-xl p-8 hover:border-cyber-blue/50 hover:shadow-cyber-glow-blue transition-all duration-300 group relative"
              style={{ transformStyle: 'preserve-3d' }}
              data-cursor-hover
            >
              {/* Quote icon */}
              <div className="absolute top-4 right-4 text-cyber-blue/30 group-hover:text-cyber-blue/50 transition-colors">
                <Quote size={24} />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={16} className="text-cyber-yellow fill-current" />
                ))}
              </div>

              {/* Content */}
              <p className="text-gray-300 mb-6 leading-relaxed italic">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="relative">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-cyber-blue/30"
                  />
                  <div className="absolute inset-0 rounded-full bg-cyber-blue/20 group-hover:bg-cyber-blue/30 transition-colors" />
                </div>
                <div>
                  <div className="font-semibold text-white">{testimonial.name}</div>
                  <div className="text-sm text-gray-400">{testimonial.role}</div>
                  <div className="text-xs text-cyber-blue font-mono">{testimonial.company}</div>
                </div>
              </div>

              {/* Glowing border effect */}
              <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow opacity-0 group-hover:opacity-20 transition-opacity duration-300 -z-10 blur-sm" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CyberpunkTestimonials;