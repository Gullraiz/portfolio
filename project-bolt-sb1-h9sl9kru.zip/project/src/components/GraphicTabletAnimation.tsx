import React, { useRef, useEffect } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { Layers, Palette, Type, Image, Brush, Pen, Square, Circle } from 'lucide-react';

const GraphicTabletAnimation: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const tabletRef = useRef<HTMLDivElement>(null);
  const stylusRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const interfaceRef = useRef<HTMLDivElement>(null);
  const layersRef = useRef<HTMLDivElement>(null);
  const paletteRef = useRef<HTMLDivElement>(null);
  const toolsRef = useRef<HTMLDivElement>(null);

  const colors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
    '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'
  ];

  const layers = [
    { name: 'Typography', visible: true, locked: false },
    { name: 'Illustration', visible: true, locked: false },
    { name: 'Background', visible: true, locked: true },
    { name: 'Sketch', visible: false, locked: false }
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 400;
    canvas.height = 300;

    // Clear canvas
    const clearCanvas = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#f8f9fa';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    };

    // Draw sketch lines
    const drawSketch = () => {
      ctx.strokeStyle = '#e9ecef';
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      
      // Draw basic shapes for sketch
      ctx.beginPath();
      ctx.arc(200, 150, 80, 0, Math.PI * 2);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.rect(120, 70, 160, 160);
      ctx.stroke();
    };

    // Draw illustration
    const drawIllustration = () => {
      // Gradient background
      const gradient = ctx.createLinearGradient(0, 0, 400, 300);
      gradient.addColorStop(0, '#667eea');
      gradient.addColorStop(1, '#764ba2');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 400, 300);

      // Main illustration elements
      ctx.fillStyle = '#FF6B6B';
      ctx.beginPath();
      ctx.arc(200, 150, 60, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#4ECDC4';
      ctx.fillRect(150, 100, 100, 100);

      ctx.fillStyle = '#FFEAA7';
      ctx.beginPath();
      ctx.moveTo(200, 80);
      ctx.lineTo(240, 140);
      ctx.lineTo(160, 140);
      ctx.closePath();
      ctx.fill();
    };

    // Draw typography
    const drawTypography = () => {
      ctx.fillStyle = '#2d3436';
      ctx.font = 'bold 32px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('DESIGN', 200, 100);
      
      ctx.font = '18px Arial';
      ctx.fillText('Creative Process', 200, 250);
    };

    // Animation sequence
    clearCanvas();
    
    return () => {
      clearCanvas();
    };
  }, []);

  useGSAP(() => {
    const tl = gsap.timeline({ repeat: -1, repeatDelay: 1 });

    // Initial setup
    gsap.set([interfaceRef.current, layersRef.current, paletteRef.current, toolsRef.current], {
      opacity: 0,
      y: 20
    });

    gsap.set(stylusRef.current, {
      x: -50,
      y: 50,
      rotation: 45
    });

    // Tablet and interface appear
    tl.to(tabletRef.current, {
      scale: 1,
      opacity: 1,
      duration: 0.8,
      ease: "back.out(1.7)"
    })
    .to([interfaceRef.current, layersRef.current, paletteRef.current, toolsRef.current], {
      opacity: 1,
      y: 0,
      duration: 0.6,
      stagger: 0.1,
      ease: "power2.out"
    }, "-=0.4")

    // Stylus animation - sketching phase
    .to(stylusRef.current, {
      x: 100,
      y: 80,
      rotation: 15,
      duration: 1,
      ease: "power2.inOut"
    })
    .to(stylusRef.current, {
      x: 200,
      y: 120,
      duration: 0.8,
      ease: "power2.inOut"
    })
    .to(stylusRef.current, {
      x: 300,
      y: 100,
      duration: 0.8,
      ease: "power2.inOut"
    })

    // Tool selection animation
    .to('.tool-brush', {
      scale: 1.2,
      backgroundColor: '#4ECDC4',
      duration: 0.3,
      ease: "power2.out"
    })
    .to('.tool-brush', {
      scale: 1,
      backgroundColor: '#e9ecef',
      duration: 0.3,
      ease: "power2.out"
    }, "+=0.5")

    // Illustration phase
    .to(stylusRef.current, {
      x: 150,
      y: 150,
      rotation: 25,
      duration: 1,
      ease: "power2.inOut"
    })
    .to('.canvas-overlay', {
      opacity: 0.8,
      duration: 0.5
    })
    .to('.canvas-overlay', {
      opacity: 0,
      duration: 0.5
    })

    // Color palette interaction
    .to('.color-swatch:nth-child(1)', {
      scale: 1.3,
      duration: 0.2,
      ease: "power2.out"
    })
    .to('.color-swatch:nth-child(1)', {
      scale: 1,
      duration: 0.2,
      ease: "power2.out"
    })

    // Typography phase
    .to('.tool-type', {
      scale: 1.2,
      backgroundColor: '#4ECDC4',
      duration: 0.3,
      ease: "power2.out"
    })
    .to(stylusRef.current, {
      x: 200,
      y: 100,
      rotation: 0,
      duration: 1,
      ease: "power2.inOut"
    })
    .to('.tool-type', {
      scale: 1,
      backgroundColor: '#e9ecef',
      duration: 0.3,
      ease: "power2.out"
    })

    // Layer visibility toggle
    .to('.layer-eye:nth-child(4)', {
      opacity: 0.3,
      duration: 0.3
    })
    .to('.layer-eye:nth-child(4)', {
      opacity: 1,
      duration: 0.3
    })

    // Final flourish
    .to(stylusRef.current, {
      x: 0,
      y: 0,
      rotation: 45,
      duration: 1,
      ease: "power2.inOut"
    })
    .to('.pressure-indicator', {
      scale: 1.5,
      opacity: 0.8,
      duration: 0.3,
      ease: "power2.out"
    })
    .to('.pressure-indicator', {
      scale: 1,
      opacity: 0.4,
      duration: 0.3,
      ease: "power2.out"
    });

    // Continuous floating animation for interface elements
    gsap.to('.floating-element', {
      y: -5,
      duration: 2,
      ease: "power2.inOut",
      yoyo: true,
      repeat: -1,
      stagger: 0.3
    });

    // Brush stroke effect
    gsap.to('.brush-stroke', {
      strokeDashoffset: 0,
      duration: 2,
      ease: "power2.inOut",
      repeat: -1,
      repeatDelay: 3
    });

  }, { scope: containerRef });

  return (
    <div ref={containerRef} className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="relative">
        {/* Main Tablet */}
        <div 
          ref={tabletRef}
          className="relative bg-gray-800 rounded-2xl p-4 shadow-2xl"
          style={{ width: '500px', height: '380px' }}
        >
          {/* Tablet Screen */}
          <div className="relative bg-white rounded-lg overflow-hidden" style={{ width: '468px', height: '348px' }}>
            {/* Canvas */}
            <canvas 
              ref={canvasRef}
              className="absolute inset-0 w-full h-full"
            />
            
            {/* Canvas Overlay for Effects */}
            <div className="canvas-overlay absolute inset-0 bg-gradient-to-r from-blue-400/20 to-purple-400/20 opacity-0" />
            
            {/* Pressure Sensitivity Indicator */}
            <div className="pressure-indicator absolute top-4 right-4 w-3 h-3 bg-green-400 rounded-full opacity-40" />
            
            {/* Brush Stroke SVG */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <path 
                className="brush-stroke"
                d="M50,200 Q200,100 350,200"
                stroke="#4ECDC4"
                strokeWidth="4"
                fill="none"
                strokeLinecap="round"
                strokeDasharray="300"
                strokeDashoffset="300"
              />
            </svg>
          </div>
        </div>

        {/* Stylus */}
        <div 
          ref={stylusRef}
          className="absolute z-10"
          style={{ top: '50px', left: '50px' }}
        >
          <div className="relative">
            <div className="w-2 h-16 bg-gradient-to-t from-gray-600 to-gray-400 rounded-full shadow-lg" />
            <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-3 bg-gray-800 rounded-full" />
            <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-gray-700 rounded-full" />
          </div>
        </div>

        {/* Interface Elements */}
        <div ref={interfaceRef} className="absolute -left-24 top-0 space-y-4">
          {/* Tools Panel */}
          <div ref={toolsRef} className="floating-element bg-white rounded-lg shadow-lg p-3 w-20">
            <div className="space-y-2">
              <div className="tool-brush w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-200 transition-colors">
                <Brush size={20} className="text-gray-600" />
              </div>
              <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-200 transition-colors">
                <Pen size={20} className="text-gray-600" />
              </div>
              <div className="tool-type w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-200 transition-colors">
                <Type size={20} className="text-gray-600" />
              </div>
              <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-200 transition-colors">
                <Square size={20} className="text-gray-600" />
              </div>
            </div>
          </div>

          {/* Color Palette */}
          <div ref={paletteRef} className="floating-element bg-white rounded-lg shadow-lg p-3 w-20">
            <div className="grid grid-cols-2 gap-1">
              {colors.slice(0, 8).map((color, index) => (
                <div 
                  key={index}
                  className="color-swatch w-6 h-6 rounded cursor-pointer hover:scale-110 transition-transform"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Layers Panel */}
        <div ref={layersRef} className="absolute -right-48 top-0 w-40">
          <div className="floating-element bg-white rounded-lg shadow-lg p-4">
            <div className="flex items-center gap-2 mb-3">
              <Layers size={16} className="text-gray-600" />
              <span className="text-sm font-medium text-gray-700">Layers</span>
            </div>
            <div className="space-y-2">
              {layers.map((layer, index) => (
                <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded text-xs">
                  <div className={`layer-eye w-3 h-3 rounded-full ${layer.visible ? 'bg-blue-400' : 'bg-gray-300'}`} />
                  <span className="flex-1 text-gray-700">{layer.name}</span>
                  {layer.locked && <div className="w-2 h-2 bg-gray-400 rounded-full" />}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Properties Panel */}
        <div className="absolute -right-48 bottom-0 w-40">
          <div className="floating-element bg-white rounded-lg shadow-lg p-4">
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-600">Brush Size</label>
                <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                  <div className="bg-blue-400 h-1 rounded-full" style={{ width: '60%' }} />
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-600">Opacity</label>
                <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                  <div className="bg-blue-400 h-1 rounded-full" style={{ width: '80%' }} />
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-600">Flow</label>
                <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                  <div className="bg-blue-400 h-1 rounded-full" style={{ width: '70%' }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Status Bar */}
        <div className="absolute -bottom-16 left-0 right-0">
          <div className="bg-white rounded-lg shadow-lg px-4 py-2 flex items-center justify-between text-xs text-gray-600">
            <span>RGB/8 • 1920x1080px</span>
            <span>100% • Layer 2</span>
            <span>Brush Tool</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GraphicTabletAnimation;