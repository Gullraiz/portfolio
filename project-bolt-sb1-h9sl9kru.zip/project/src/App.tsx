import React, { useEffect, useRef, useState } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { TextPlugin } from 'gsap/TextPlugin';
import { Moon, Sun, Github, Linkedin, Mail, ExternalLink, Menu, X } from 'lucide-react';
import Lenis from 'lenis';
import CyberpunkCursor from './components/CyberpunkCursor';
import CyberpunkHero from './components/CyberpunkHero';
import CyberpunkNavigation from './components/CyberpunkNavigation';
import CyberpunkAbout from './components/CyberpunkAbout';
import CyberpunkServices from './components/CyberpunkServices';
import CyberpunkPortfolio from './components/CyberpunkPortfolio';
import CyberpunkSkills from './components/CyberpunkSkills';
import CyberpunkTestimonials from './components/CyberpunkTestimonials';
import CyberpunkPricing from './components/CyberpunkPricing';
import CyberpunkContact from './components/CyberpunkContact';
import CyberpunkPreloader from './components/CyberpunkPreloader';
import CyberpunkBackground from './components/CyberpunkBackground';
import GraphicTabletAnimation from './components/GraphicTabletAnimation';

gsap.registerPlugin(ScrollTrigger, TextPlugin);

function App() {
  const [loading, setLoading] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    // Check for reduced motion preference
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mediaQuery.matches);
    
    const handleChange = (e: MediaQueryListEvent) => {
      setReducedMotion(e.matches);
    };
    
    mediaQuery.addEventListener('change', handleChange);
    
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  useEffect(() => {
    // Initialize Lenis smooth scrolling
    if (!reducedMotion) {
      lenisRef.current = new Lenis({
        duration: 1.2,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        direction: 'vertical',
        gestureDirection: 'vertical',
        smooth: true,
        mouseMultiplier: 1,
        smoothTouch: false,
        touchMultiplier: 2,
        infinite: false,
      });

      function raf(time: number) {
        lenisRef.current?.raf(time);
        requestAnimationFrame(raf);
      }

      requestAnimationFrame(raf);
    }

    return () => {
      lenisRef.current?.destroy();
    };
  }, [reducedMotion]);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  // Global scroll progress indicator
  useGSAP(() => {
    const progressBar = document.querySelector('.scroll-progress');
    if (progressBar) {
      ScrollTrigger.create({
        trigger: document.body,
        start: 'top top',
        end: 'bottom bottom',
        onUpdate: (self) => {
          gsap.to(progressBar, {
            scaleX: self.progress,
            duration: 0.1,
            ease: 'none'
          });
        }
      });
    }
  });

  if (loading) {
    return <CyberpunkPreloader />;
  }

  // Show tablet animation for demo
  if (window.location.hash === '#tablet-demo') {
    return <GraphicTabletAnimation />;
  }

  return (
    <div 
      ref={containerRef}
      className={`min-h-screen bg-cyber-black text-white overflow-x-hidden ${
        reducedMotion ? 'motion-reduce' : ''
      }`}
    >
      {!reducedMotion && <CyberpunkCursor />}
      <CyberpunkBackground />
      
      {/* Global scroll progress indicator */}
      <div className="fixed top-0 left-0 w-full h-1 z-50 bg-cyber-black/20">
        <div className="scroll-progress h-full bg-gradient-to-r from-cyber-blue via-cyber-pink to-cyber-yellow origin-left scale-x-0" />
      </div>

      <CyberpunkNavigation />
      <CyberpunkHero />
      <CyberpunkAbout />
      <CyberpunkServices />
      <CyberpunkPortfolio />
      <CyberpunkSkills />
      <CyberpunkTestimonials />
      <CyberpunkPricing />
      <CyberpunkContact />

      {/* Footer */}
      <footer className="relative py-12 border-t border-cyber-blue/20">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex justify-center gap-6 mb-6">
            <a 
              href="#" 
              className="p-3 rounded-lg bg-cyber-black/50 border border-cyber-blue/30 hover:border-cyber-blue hover:shadow-cyber-glow-blue transition-all duration-300"
              data-cursor-hover
            >
              <Github size={20} />
            </a>
            <a 
              href="#" 
              className="p-3 rounded-lg bg-cyber-black/50 border border-cyber-pink/30 hover:border-cyber-pink hover:shadow-cyber-glow-pink transition-all duration-300"
              data-cursor-hover
            >
              <Linkedin size={20} />
            </a>
            <a 
              href="#" 
              className="p-3 rounded-lg bg-cyber-black/50 border border-cyber-yellow/30 hover:border-cyber-yellow hover:shadow-cyber-glow-yellow transition-all duration-300"
              data-cursor-hover
            >
              <Mail size={20} />
            </a>
          </div>
          <p className="text-gray-400 text-sm">
            © 2025 Cyberpunk Portfolio. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;