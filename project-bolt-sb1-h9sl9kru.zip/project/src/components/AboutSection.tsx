import React, { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const AboutSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);
  const shapeRef = useRef<HTMLDivElement>(null);

  const skills = [
    { name: 'Brand Identity', level: 95 },
    { name: 'UI/UX Design', level: 90 },
    { name: 'Web Design', level: 85 },
    { name: 'Motion Graphics', level: 80 },
    { name: 'Illustration', level: 75 },
    { name: 'Photography', level: 70 }
  ];

  useGSAP(() => {
    // Animate text reveal
    if (textRef.current) {
      gsap.fromTo(textRef.current.children,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.2,
          ease: "power2.out",
          scrollTrigger: {
            trigger: textRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }

    // Animate skill bars
    if (skillsRef.current) {
      const skillBars = skillsRef.current.querySelectorAll('.skill-bar');
      const skillFills = skillsRef.current.querySelectorAll('.skill-fill');
      
      gsap.fromTo(skillBars,
        { opacity: 0, x: -50 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: skillsRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      skillFills.forEach((fill, index) => {
        gsap.fromTo(fill,
          { width: '0%' },
          {
            width: `${skills[index].level}%`,
            duration: 1.5,
            ease: "power2.out",
            scrollTrigger: {
              trigger: fill,
              start: "top 80%",
              end: "bottom 20%",
              toggleActions: "play none none reverse"
            }
          }
        );
      });
    }

    // Animate morphing shape
    if (shapeRef.current) {
      gsap.to(shapeRef.current, {
        rotation: 360,
        duration: 20,
        ease: "none",
        repeat: -1
      });

      gsap.to(shapeRef.current, {
        scale: 1.2,
        duration: 4,
        ease: "power2.inOut",
        yoyo: true,
        repeat: -1
      });
    }

  }, { scope: containerRef });

  return (
    <section id="about" ref={containerRef} className="py-20 bg-white dark:bg-gray-900 relative overflow-hidden">
      {/* Morphing background shape */}
      <div 
        ref={shapeRef}
        className="absolute top-1/2 right-0 w-96 h-96 bg-gradient-to-br from-blue-400 to-purple-600 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-3xl opacity-20 transform translate-x-1/2 -translate-y-1/2"
      />

      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Text Content */}
          <div ref={textRef} className="space-y-8">
            <div>
              <h2 className="text-5xl md:text-6xl font-black mb-6">
                About Me
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                I'm a passionate graphic designer with over 8 years of experience creating 
                memorable brand identities and digital experiences. My approach combines 
                strategic thinking with creative execution to deliver designs that not only 
                look great but also drive results.
              </p>
            </div>

            <div>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                I believe in the power of design to transform businesses and create 
                meaningful connections between brands and their audiences. Every project 
                is an opportunity to tell a unique story through visual language.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              {['Adobe Creative Suite', 'Figma', 'Sketch', 'Cinema 4D', 'Blender'].map((tool) => (
                <span 
                  key={tool}
                  className="px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-full text-sm font-medium hover:bg-blue-100 dark:hover:bg-blue-900 transition-colors"
                >
                  {tool}
                </span>
              ))}
            </div>
          </div>

          {/* Skills */}
          <div ref={skillsRef} className="space-y-6">
            <h3 className="text-2xl font-bold mb-8">Skills & Expertise</h3>
            {skills.map((skill, index) => (
              <div key={skill.name} className="skill-bar">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className="skill-fill bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full"
                    style={{ width: '0%' }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;