/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Inter', 'ui-sans-serif', 'system-ui'],
        'mono': ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      colors: {
        'cyber-black': '#0A0A0F',
        'cyber-blue': '#00FFFF',
        'cyber-pink': '#FF10F0',
        'cyber-yellow': '#FFDD00',
        'cyber-purple': '#8B5CF6',
        'cyber-green': '#00FF41',
      },
      animation: {
        'pulse': 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 3s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'glitch': 'glitch 0.3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        glow: {
          '0%': { boxShadow: '0 0 5px currentColor' },
          '100%': { boxShadow: '0 0 20px currentColor, 0 0 30px currentColor' },
        },
        glitch: {
          '0%': { transform: 'translate(0)' },
          '20%': { transform: 'translate(-2px, 2px)' },
          '40%': { transform: 'translate(-2px, -2px)' },
          '60%': { transform: 'translate(2px, 2px)' },
          '80%': { transform: 'translate(2px, -2px)' },
          '100%': { transform: 'translate(0)' },
        }
      },
      boxShadow: {
        'cyber-glow-blue': '0 0 20px rgba(0, 255, 255, 0.5), 0 0 40px rgba(0, 255, 255, 0.3)',
        'cyber-glow-pink': '0 0 20px rgba(255, 16, 240, 0.5), 0 0 40px rgba(255, 16, 240, 0.3)',
        'cyber-glow-yellow': '0 0 20px rgba(255, 221, 0, 0.5), 0 0 40px rgba(255, 221, 0, 0.3)',
      },
      backdropBlur: {
        xs: '2px',
      },
      backgroundImage: {
        'cyber-gradient': 'linear-gradient(45deg, #00FFFF, #FF10F0, #FFDD00)',
        'cyber-grid': `
          linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
          linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px)
        `,
      }
    },
  },
  plugins: [],
  safelist: [
    'text-cyber-blue',
    'text-cyber-pink', 
    'text-cyber-yellow',
    'border-cyber-blue',
    'border-cyber-pink',
    'border-cyber-yellow',
    'bg-cyber-blue',
    'bg-cyber-pink',
    'bg-cyber-yellow',
    'shadow-cyber-glow-blue',
    'shadow-cyber-glow-pink',
    'shadow-cyber-glow-yellow',
    'hover:border-cyber-blue',
    'hover:border-cyber-pink',
    'hover:border-cyber-yellow',
    'hover:bg-cyber-blue/10',
    'hover:bg-cyber-pink/10',
    'hover:bg-cyber-yellow/10',
  ]
};